﻿using GmodNET.API;
using System;

namespace GmodHelloWorld
{
    public class Setup : IModule
    {
        public string ModuleName => "Hello World";

        public string ModuleVersion => "0.1.0";

        public void Load(ILua lua, bool is_serverside, GetILuaFromLuaStatePointer lua_extructor, ModuleAssemblyLoadContext assembly_context)
        {
            lua.PushSpecial(GmodNET.API.SPECIAL_TABLES.SPECIAL_GLOB);
            lua.GetField(-1, "print");
            lua.PushString("Hello World!");
            lua.MCall(1, 0);
            lua.Pop(1);
        }

        public void Unload()
        {

        }
    }
}
